<?php
include 'db.php';
session_start();

if(!isset($_GET['id'])){
    header("Location: dashboard_ui.php");
    exit;
}

$id = intval($_GET['id']);
$sql = "UPDATE news SET deleted=1 WHERE id=$id";
mysqli_query($conn, $sql);
header("Location: dashboard_ui.php");
exit;
?>