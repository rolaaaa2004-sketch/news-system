<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "DELETE FROM categories WHERE id = $id";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert(' Category deleted successfully!'); window.location.href='view_categories_ui.php';</script>";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo " No category ID provided.";
}
?>