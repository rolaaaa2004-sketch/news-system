<?php
include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add News</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="db.css" rel="stylesheet">
</head>
<body>

    <div class="sidebar">
    <h3 class="mb-4">Menu</h3>
    <a href="categories_ui.php">Add Category</a>
    <a href="view_categories_ui.php">View Categories</a>
    <a href="add_news_ui.php">Add News</a>
    <a href="delete_news.php">Deleted News</a>
    <a href="landindpage.php">landing page</a>

</div>
<div class="content">
    <h2 class="mb-4">Add News</h2>

    <div class="card shadow-sm">
        <div class="card-body">
            <form action="add_news_logic.php" method="POST" enctype="multipart/form-data">
                
                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" placeholder="Enter news title" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Details</label>
                    <textarea name="details" class="form-control" rows="4" placeholder="Enter news details" required></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="category_id" class="form-select" required>
                        <option value="">-- Select Category --</option>
                        <?php
                        $res = mysqli_query($conn, "SELECT * FROM categories");
                        while($row = mysqli_fetch_assoc($res)){
                            echo "<option value='{$row['id']}'>{$row['name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Image</label>
                    <input type="file" name="image" class="form-control" required>
                </div>

                <button type="submit" name="save" class="btn btn-primary">Save News</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>