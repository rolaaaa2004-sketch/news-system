<?php
include 'db.php';
session_start();

if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);

    $update = mysqli_query($conn, "UPDATE categories SET name='$name' WHERE id=$id");
    if ($update) {
        $_SESSION['success'] = "Category updated successfully!";
        header("Location: view_categories_ui.php");
        exit;
    } else {
        $_SESSION['error'] = "Failed to update category.";
        header("Location: edit_category.php?id=$id");
        exit;
    }
}