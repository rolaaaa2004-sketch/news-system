<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>News System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #f7eeadff, #ff5e62);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            text-align: center;
            background-color: white;
            max-width: 500px;
        }
        .btn-custom {
            width: 150px;
            margin: 0.5rem;
            font-weight: bold;
        }
        h1 {
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        p {
            font-size: 1.1rem;
            color: #555;
        }
    </style>
</head>
<body>

<div class="card">
    <h1> Welcome to Your News Playground! </h1>
    <p>Discover, share, and rule the news your way!</p>
    <div>
        <a href="login_ui.php" class="btn btn-primary btn-custom">Login</a>
        <a href="register_ui.php" class="btn btn-success btn-custom">Create Account</a>
    </div>
</div>

</body>
</html>