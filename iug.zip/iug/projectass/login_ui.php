<?php 

include 'db.php';

session_start();
if(isset($_SESSION['error'])){
  echo '<div class="alert alert-danger">'.$_SESSION['error'].'</div>';
  unset($_SESSION['error']);
}
if(isset($_SESSION['success'])){
  echo '<div class="alert alert-success">'.$_SESSION['success'].'</div>';
  unset($_SESSION['success']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="db.css" rel="stylesheet">
</head>
<body class="bg-light">
      <div class="sidebar">
    <h3 class="mb-4">Menu</h3>
    <a href="categories_ui.php">Add Category</a>
    <a href="view_categories_ui.php">View Categories</a>
    <a href="add_news_ui.php">Add News</a>
    <a href="delete_news.php">Deleted News</a>
    <a href="landindpage.php">landing page</a>

</div>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-5">
      <div class="card shadow-sm">
        <div class="card-body">
          <h3 class="text-center mb-4">Login</h3>

          <?php if(isset($_GET['error'])): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
          <?php endif; ?>

          <form action="login_logic.php" method="POST">
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
          </form>

          <p class="mt-3 text-center">
            Don't have an account? <a href="register_ui.php">Register here</a>
          </p>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>