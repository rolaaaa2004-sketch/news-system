<?php
include 'db.php';   
include 'dashbord_logic.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="db.css" rel="stylesheet">
</head>
<body>

    <div class="sidebar">
    <h3 class="mb-4">Menu</h3>
    <a href="categories_ui.php">Add Category</a>
    <a href="view_categories_ui.php">View Categories</a>
    <a href="add_news_ui.php">Add News</a>
    <a href="delete_news.php">Deleted News</a>
    <a href="landindpage.php">landing page</a>

</div>

<div class="content">
    <h2 class="mb-4">News Dashboard</h2>

    <?php if(isset($error_message)): ?>
        <div class="alert alert-danger">
            <?= $error_message ?>
        </div>
    <?php endif; ?>

    <?php if(empty($news_query) || $news_query->num_rows === 0): ?>
        <div class="alert alert-info">
            No news available at the moment.
        </div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php while($news = $news_query->fetch_assoc()): ?>
                <div class="col">
                    <div class="card h-100 shadow-sm border-0">
                        <?php if($news['image']): ?>
                            <img src="img/<?= $news['image'] ?>" class="card-img-top" alt="News Image">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/300x200?text=No+Image" class="card-img-top" alt="No Image">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?= $news['title'] ?></h5>
                            <p class="card-text"><strong>Category:</strong> <?= $news['category_name'] ?></p>
                            <p class="card-text"><strong>Author:</strong> <?= $news['user_name'] ?></p>
                            <p class="card-text"><?= substr($news['details'],0,100) ?>...</p>
                        </div>
                        <div class="card-footer d-flex justify-content-between">
                            <a href="edit_news_ui.php?id=<?= $news['id'] ?>" class="btn btn-success btn-sm">Edit</a>
                            <a href="delete_news.php?id=<?= $news['id'] ?>" class="btn btn-danger btn-sm">Delete</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>