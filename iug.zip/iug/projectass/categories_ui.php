<?php
include 'db.php';

$res = mysqli_query($conn, "SELECT * FROM categories ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Categories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="db.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
    <h3 class="mb-4">Menu</h3>
    <a href="categories_ui.php">Add Category</a>
    <a href="view_categories_ui.php">View Categories</a>
    <a href="add_news_ui.php">Add News</a>
    <a href="delete_news.php">Deleted News</a>
</div>

<div class="content">
    <h2 class="mb-4">Categories</h2>


    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($res)): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td>
                                <a href="delete_category.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
                                <a href="edit_category.php?id=<?= $row['id'] ?>" class="btn btn-success btn-sm">Edit</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <h4>Add New Category</h4>
            <form action="add_category_logic.php" method="POST" class="mt-3">
                <div class="mb-3">
                    <input type="text" name="name" class="form-control" placeholder="Category Name" required>
                </div>
                <button type="submit" name="save" class="btn btn-primary">Add Category</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>