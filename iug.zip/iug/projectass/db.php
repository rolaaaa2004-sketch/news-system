<?php
$conn = mysqli_connect("localhost", "root", "", "dbproject");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Database Connection</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<!-- <body class="bg-light">
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-body text-center"> -->
            <?php
            if (!$conn) {
                // echo '<h4 class="text-danger"> Connection failed: ' . mysqli_connect_error() . '</h4>';
            } else {
                // echo '<h4 class="text-success"> Connected to database <strong>dbproject2</strong> successfully!</h4>';
            }
            ?>
        </div>
    </div>
</div>
</body>
</html>