<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){
    echo("You must be logged in to add news.");
}

$user_id = $_SESSION['user_id'];

$title = mysqli_real_escape_string($conn, $_POST['title']);
$details = mysqli_real_escape_string($conn, $_POST['details']);
$category_id = intval($_POST['category_id']);

$image = "";
if(isset($_FILES['image']) && $_FILES['image']['name'] != ""){
    $image = time() . "_" . basename($_FILES['image']['name']);
    $target_dir = "img/";
    $target_file = $target_dir . $image;
    
    if(!move_uploaded_file($_FILES['image']['tmp_name'], $target_file)){
        echo("Failed to upload image.");
    }
}

$query = "INSERT INTO news (title, details, category_id, user_id, image) 
          VALUES ('$title', '$details', $category_id, $user_id, '$image')";

if(mysqli_query($conn, $query)){
    header("Location: dashboard_ui.php"); 
    exit;
} else {
    die("Error adding news: " . mysqli_error($conn));
}
?>