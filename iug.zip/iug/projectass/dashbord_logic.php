<?php
session_start();
include 'db.php'; 

$news_query = $conn->query("
    SELECT news.*, categories.name AS category_name, users.name AS user_name
    FROM news
    JOIN categories ON news.category_id = categories.id
    JOIN users ON news.user_id = users.id
    WHERE news.deleted = 0
    ORDER BY news.id DESC
");

if (!$news_query) {
    $error_message = "Error fetching news: " . $conn->error;
    $news_query = []; 
}