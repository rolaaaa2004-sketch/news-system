<?php
include 'db.php';
if(isset($_POST['save'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $sql = "INSERT INTO categories (name) VALUES ('$name')";
    mysqli_query($conn, $sql);
    header("Location: view_categories_ui.php");
    exit;
}
?>