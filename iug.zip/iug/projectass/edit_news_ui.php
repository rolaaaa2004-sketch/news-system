<?php
include 'db.php';

if(!isset($_GET['id'])){
    echo "<div class='alert alert-danger mt-4'>News ID not provided.</div>";
    exit;
}

$id = intval($_GET['id']);
$res = mysqli_query($conn, "SELECT * FROM news WHERE id=$id");
if(mysqli_num_rows($res) == 0){
    echo "<div class='alert alert-danger mt-4'>News not found.</div>";
    exit;
}
$news = mysqli_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit News</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="db.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
    <h3 class="mb-4">Menu</h3>
    <a href="categories_ui.php">Add Category</a>
    <a href="view_categories_ui.php">View Categories</a>
    <a href="add_news_ui.php">Add News</a>
    <a href="delete_news.php">Deleted News</a>
    <a href="landindpage.php">landing page</a>

</div>



<div class="content">
    <h2 class="mb-4">Edit News</h2>

    <div class="card shadow-sm">
        <div class="card-body">
            <form action="edit_news_logic.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?= $news['id'] ?>">

                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($news['title']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Details</label>
                    <textarea name="details" class="form-control" rows="4" required><?= htmlspecialchars($news['details']) ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <select name="category_id" class="form-select" required>
                        <?php
                        $res_cat = mysqli_query($conn, "SELECT * FROM categories");
                        while($cat = mysqli_fetch_assoc($res_cat)){
                            $selected = ($cat['id'] == $news['category_id']) ? "selected" : "";
                            echo "<option value='{$cat['id']}' $selected>{$cat['name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Current Image</label><br>
                    <?php if($news['image']): ?>
                        <img src="img/<?= $news['image'] ?>" width="150" class="mb-2">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/150?text=No+Image" class="mb-2">
                    <?php endif; ?>
                    <input type="file" name="image" class="form-control">
                </div>

                <button type="submit" name="update" class="btn btn-success">Update News</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>