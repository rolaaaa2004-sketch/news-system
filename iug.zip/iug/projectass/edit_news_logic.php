<?php
include 'db.php';
session_start();

if(isset($_POST['update'])){
    $id = intval($_POST['id']);
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $details = mysqli_real_escape_string($conn, $_POST['details']);
    $category_id = intval($_POST['category_id']);

    $image_sql = "";
    if(!empty($_FILES['image']['name'])){
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $target = "img/".$image_name;
        if(move_uploaded_file($image_tmp, $target)){
            $image_sql = ", image='$image_name'";
        }
    }

    $sql = "UPDATE news SET title='$title', details='$details', category_id=$category_id $image_sql WHERE id=$id";
    if(mysqli_query($conn, $sql)){
        header("Location: dashboard_ui.php");
        exit;
    } else {
        echo "<div class='alert alert-danger mt-4'>DB Error: ".mysqli_error($conn)."</div>";
    }
}
?>