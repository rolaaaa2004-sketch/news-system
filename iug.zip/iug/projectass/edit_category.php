<?php
include 'db.php';
session_start();

if (!isset($_GET['id'])) {
    echo "<div class='alert alert-danger mt-4'>Category ID not provided.</div>";
    exit;
}

$id = intval($_GET['id']);

$res = mysqli_query($conn, "SELECT * FROM categories WHERE id = $id");
if (mysqli_num_rows($res) == 0) {
    echo "<div class='alert alert-danger mt-4'>Category not found.</div>";
    exit;
}

$category = mysqli_fetch_assoc($res);
?>

<div class="container mt-5">
    <h2>Edit Category</h2>
    <form action="edit_category_logic.php" method="POST" class="mt-3">
        <input type="hidden" name="id" value="<?= $category['id'] ?>">
        <div class="mb-3">
            <label>Category Name</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($category['name']) ?>" required>
        </div>
        <button type="submit" name="update" class="btn btn-success">Update Category</button>
        <a href="view_categories_ui.php" class="btn btn-secondary">Back</a>
    </form>
</div>