
<?php
include 'db.php';
session_start();


$res = mysqli_query($conn, "SELECT * FROM categories ORDER BY id DESC");
?>

<div class="container mt-5">
    <h2 class="mb-4">Categories</h2>

    <?php
    if(isset($_SESSION['error'])){
        echo '<div class="alert alert-danger">'.$_SESSION['error'].'</div>';
        unset($_SESSION['error']);
    }
    if(isset($_SESSION['success'])){
        echo '<div class="alert alert-success">'.$_SESSION['success'].'</div>';
        unset($_SESSION['success']);
    }
    ?>

    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-hover">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($res)): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td>
                        <a href="edit_category.php?id=<?=$row['id']?>"class="btn btn-success btn-sm">Edit</a>
                        <a href="delete_category.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <h4>Add New Category</h4>
        <form action="add_category_logic.php" method="POST" class="mt-3">
            <div class="mb-3">
                <input type="text" name="name" class="form-control" placeholder="Category Name" required>
            </div>
            <button type="submit" name="save" class="btn btn-primary">Add Category</button>
        </form>
    </div>
</div>